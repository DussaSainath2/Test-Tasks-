package com.example.curtainapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurtainappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurtainappApplication.class, args);
	}

}
